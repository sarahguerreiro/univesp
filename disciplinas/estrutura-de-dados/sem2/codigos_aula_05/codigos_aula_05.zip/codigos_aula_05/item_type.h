typedef char ItemType;
